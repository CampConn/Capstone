tensorflow-utils
===================
This library contains classes and methods to make using TensorFlow easier.

At the moment it only contains context managers for creating graphs and session.

Installation
------------
**User Install**

.. code-block:: bash

  pip install --user tensorflow-utils

**Developer Install**

.. code-block:: bash

  git clone https://github.com/stefanwebb/tensorflow-utils.git
  cd tensorflow-utils
  python setup.py develop

Creating graphs
------------
After importing the library,

.. code-block:: python

  import tensorflow_utils as tf_utils

we enter a context manager for a new graph as,

.. code-block:: python

  with tf_utils.contexts.GraphContext() as graph_context:

This context manager takes a number of useful arguments for a default device, random seeds to NumPy and TensorFlow, and an existing graph object. For example,

.. code-block:: python

  with tf_utils.contexts.GraphContext(graph=existing_graph) as graph_context:
  with tf_utils.contexts.GraphContext(device='gpu:0') as graph_context:
  with tf_utils.contexts.GraphContext(device='gpu:0', np_seed=1, tf_seed=2) as graph_context:

Creating sessions
------------
Creating sessions is likewise as simple with the following context manager,

.. code-block:: python

  with tf_utils.contexts.SessionContext() as session_context:

It has a number of useful keyword parameter options,

.. code-block:: python

  with tf_utils.contexts.SessionContext(
    soft_placement=True, 
    gpu_allow_growth=True,
    gpu_restrict_devices=0) as session_context:

Using the session manager has a number of benefits,

- global and local variables are initialized after entering the manager
- a ``tf.train.Saver`` is created if trainable variables have been defined in the current graph
- queue runners are started and the queue populated if they have been defined in the graph, and these threads are terminated when the manager is exited
- stopping queue runners with the ``stop()`` method, and testing whether they are running with ``running()``

