# MIT License
#
# Copyright (c) 2017, Stefan Webb. All Rights Reserved.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy 
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
# copies of the Software, and to permit persons to whom the Software is 
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in 
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE 
# SOFTWARE.

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

#import os, sys, six
#from enum import Enum

import tensorflow as tf
import numpy as np

import tensorflow_utils.contexts

# It's best to keep all model information stored in the graph, these extra keys are helpful for that
class GraphKeys(object):
	INPUTS = 'inputs'
	PRIOR = 'prior'
	PLACEHOLDERS = 'placeholders'
	OUTPUTS = 'outputs'
	ENCODERS = 'encoders'
	DECODERS = 'decoders'
	LOSSES = 'losses'
	INFERENCE = 'inference'

# Flatten out the HWC dimensions of a tensor, leave a normal one unchanged
def flatten(x):
	if len(x.shape) > 2:
		x = tf.reshape(x, [int(x.shape[0]), -1])
	return x

# Sum out the HWC or length dimensions of a tensor uniformly
def reduce_sum(x):
	return tf.reduce_sum(flatten(x), 1)

def safe_log(x, **kwargs):
	#return tf.log(x + 1e-16, **kwargs)
	return tf.log(x + 1e-8, **kwargs)

def global_step():
	return tf.contrib.framework.get_or_create_global_step()

'''def local_step(settings, name='local_step', start=0):
	with cpu_device(settings):
		step = tf.Variable(start, name=name, trainable=False)'''

# TODO: Make this take an argument to the CPU number with default 0
def host():
	return tf.device("/cpu:0")

#def device(settings):
#	return tf.device("/" + settings['device'])

# TODO: Think about the naming of the following
# Get trainable variables with a given substring
def get_vars(name):
	variables = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES)
	selected = []
	for v in variables:
		if name in v.name:
			selected.append(v)
	return v

def get_prior():
	ops = tf.get_collection(GraphKeys.PRIOR)
	if not ops is []:
		return ops[0]
	else:
		raise ValueError('No prior sampling operation exists')

def get_decoder():
	ops = tf.get_collection(GraphKeys.DECODERS)
	if not ops is []:
		return ops[0]
	else:
		return None
		#raise ValueError('No decoder sampling operation exists')

def get_encoder():
	ops = tf.get_collection(GraphKeys.ENCODERS)
	if not ops is []:
		return ops[0]
	else:
		return None
		#raise ValueError('No encoder sampling operation exists')

def get_output(name):
	ops = tf.get_collection(GraphKeys.OUTPUTS)
	for op in ops:
		if name in op.name:
			return op
	raise ValueError('No output operation with substring "{}" exists'.format(name))

def get_loss(name):
	ops = tf.get_collection(GraphKeys.LOSSES)
	for op in ops:
		if name in op.name:
			return op
	raise ValueError('No loss operation with substring "{}" exists'.format(name))

def get_inference(name):
	ops = tf.get_collection(GraphKeys.INFERENCE)
	for op in ops:
		if name in op.name:
			return op
	raise ValueError('No inference operation with substring "{}" exists'.format(name))

def samples_placeholder():
	placeholders = tf.get_collection(GraphKeys.PLACEHOLDERS)
	for p in placeholders:
		if 'samples' in p.name:
			return p
	return None

def train_placeholder():
	placeholders = tf.get_collection(GraphKeys.INPUTS)
	for p in placeholders:
		if 'train/samples' in p.name:
			return p
	return None

def test_placeholder():
	placeholders = tf.get_collection(GraphKeys.INPUTS)
	for p in placeholders:
		if 'test/samples' in p.name:
			return p
	return None

def codes_placeholder():
	placeholders = tf.get_collection(GraphKeys.PLACEHOLDERS)
	for p in placeholders:
		if 'codes' in p.name:
			return p
	return None

def standard_normal(shape, name='MultivariateNormalDiag'):
	return tf.contrib.distributions.MultivariateNormalDiag(tf.zeros(shape), tf.ones(shape), name=name)

def standard_uniform(name='Uniform'):
	return tf.contrib.distributions.Uniform(name=name)

def gan_uniform(name='Uniform'):
	try:
		return tf.contrib.distributions.Uniform(a=-1., b=1., name=name)
	except:
		return tf.contrib.distributions.Uniform(low=-1., high=1., name=name)